﻿using Contoso.AADB2C.APIClientCert.Models;
using Newtonsoft.Json;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Web.Http;

namespace Contoso.AADB2C.APIClientCert
{
    public class IdentityController : ApiController
    {
        [HttpPost]
        public IHttpActionResult SignUp()
        {
            if (IsValidClientCertificate() == false)
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Your client certificate is not valid", HttpStatusCode.Conflict));
            }

            // If not data came in, then return
            if (this.Request.Content == null) throw new Exception();

            // Read the input claims from the request body
            string input = Request.Content.ReadAsStringAsync().Result;

            // Check input content value
            if (string.IsNullOrEmpty(input))
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Request content is empty", HttpStatusCode.Conflict));
            }

            // Convert the input string into InputClaimsModel object
            InputClaimsModel inputClaims = JsonConvert.DeserializeObject(input, typeof(InputClaimsModel)) as InputClaimsModel;

            if (inputClaims == null)
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Can not deserialize input claims", HttpStatusCode.Conflict));
            }

            // Run input validation
            if (inputClaims.firstName.ToLower() == "test")
            {
                return Content(HttpStatusCode.Conflict, new B2CResponseContent("Test name is not valid, please provide a valid name", HttpStatusCode.Conflict));
            }

            // Create output claims object and set the loyalty number with random value
            OutputClaimsModel outputClaims = new OutputClaimsModel();
            outputClaims.loyaltyNumber = new Random().Next(100, 1000).ToString();

            // Return the output claim(s)
            return Ok(outputClaims);
        }

        private bool IsValidClientCertificate()
        {
            string ClientCertificateSubject = ConfigurationManager.AppSettings["ClientCertificate:Subject"];
            string ClientCertificateIssuer = ConfigurationManager.AppSettings["ClientCertificate:Issuer"];
            string ClientCertificateThumbprint = ConfigurationManager.AppSettings["ClientCertificate:Thumbprint"];

            X509Certificate2 clientCertInRequest = RequestContext.ClientCertificate;
            if (clientCertInRequest == null)
            {
                Trace.WriteLine("Certificate is NULL");
                return false;
            }

            // Basic verification
            if (clientCertInRequest.Verify() == false)
            {
                Trace.TraceError("Basic verification failed");
                return false;
            }

            // 1. Check time validity of certificate
            if (DateTime.Compare(DateTime.Now, clientCertInRequest.NotBefore) < 0 ||
                DateTime.Compare(DateTime.Now, clientCertInRequest.NotAfter) > 0)
            {
                Trace.TraceError($"NotBefore '{clientCertInRequest.NotBefore}' or NotAfter '{clientCertInRequest.NotAfter}' not valid");
                return false;
            }

            // 2. Check subject name of certificate
            bool foundSubject = false;
            string[] certSubjectData = clientCertInRequest.Subject.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in certSubjectData)
            {
                if (String.Compare(s.Trim(), ClientCertificateSubject) == 0)
                {
                    foundSubject = true;
                    break;
                }
            }

            if (!foundSubject)
            {
                Trace.TraceError($"Subject name '{clientCertInRequest.Subject}' is not valid");
                return false;
            }

            // 3. Check issuer name of certificate
            bool foundIssuerCN = false;
            string[] certIssuerData = clientCertInRequest.Issuer.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string s in certIssuerData)
            {
                if (String.Compare(s.Trim(), ClientCertificateIssuer) == 0)
                {
                    foundIssuerCN = true;
                    break;
                }
            }

            if (!foundIssuerCN)
            {
                Trace.TraceError($"Issuer '{clientCertInRequest.Issuer}' is not valid");
                return false;
            }

            // 4. Check thumprint of certificate
            if (String.Compare(clientCertInRequest.Thumbprint.Trim().ToUpper(), ClientCertificateThumbprint) != 0)
            {
                Trace.TraceError($"Thumbprint '{clientCertInRequest.Thumbprint.Trim().ToUpper()}' is not valid");
                return false;
            }

            // 5. If you also want to test if the certificate chains to a Trusted Root Authority you can uncomment the code below
            //
            //X509Chain certChain = new X509Chain();
            //certChain.Build(certificate);
            //bool isValidCertChain = true;
            //foreach (X509ChainElement chElement in certChain.ChainElements)
            //{
            //    if (!chElement.Certificate.Verify())
            //    {
            //        isValidCertChain = false;
            //        break;
            //    }
            //}
            //if (!isValidCertChain) return false;
            return true;
        }
    }
}
